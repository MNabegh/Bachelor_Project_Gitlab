package no.uio.subjective_logic.opinion;

public interface OpinionTextualizer
{
  String textualize(Opinion paramOpinion);
}