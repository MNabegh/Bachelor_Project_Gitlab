package no.uio.subjective_logic.opinion;

public class OpinionArithmeticException extends ArithmeticException
{
  private static final long serialVersionUID = 1L;

  public OpinionArithmeticException()
  {
  }

  public OpinionArithmeticException(String arg0)
  {
    super(arg0);
  }
}